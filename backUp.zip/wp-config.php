<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/var/www/u0676621/data/www/utrust.lv/wp-content/plugins/wp-super-cache/' );
define('DB_NAME', 'u0676621_default');

/** Имя пользователя MySQL */
define('DB_USER', 'u0676621_default');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'REDblue2000$$$');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'bO~`Pbw2I*hwvW%f]}i=Y$?6uQ`CE&*fzO0$s,ELjv{EqV-wjQYW5`W.J@qM(2mp');
define('SECURE_AUTH_KEY',  ';2sIxrrrkTcL+a_LVI14)w gGFuS8w0E7b/MBa-WU~#+WcVZ`ohu/iQLT]/ZQp^8');
define('LOGGED_IN_KEY',    'M>Fe=*.`RIQT#9^@|BoEtwQ,|fOv>iFr{ns(XLK{!x:SQ;-.kbrGH$MWUUtQl6(5');
define('NONCE_KEY',        '. ?iYlD3T7lFVnnN0dmDUO,3RvQCP=uW{l.FLv/?%zLlOKdd./V=4m-IcrKR*d<S');
define('AUTH_SALT',        'wY6>[{gIRWZk:&SVdda$vDUq/=9lpOB7[Ys|1(4U6>JH3Fh~`-nrU6xv ZP1Nhp7');
define('SECURE_AUTH_SALT', '?a{?L%6>d77weNWGKB&0{g>dtE;RA<mqY; xn@=$7.v+SddTK_WG9hMtc<|H0`.%');
define('LOGGED_IN_SALT',   'I0q2AER=Nhepu1yh7}]=w<peQ2VWT^}yS;ls2yVJ;l3-x>b6Y27Q4L{nbYa?4/E ');
define('NONCE_SALT',       '_O{8.~<-dW(^%~D`XGQ@p5*mBRV$!{: =9#il}p~M:LXgUmG2H3@FL4%g`J6.E6n');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
